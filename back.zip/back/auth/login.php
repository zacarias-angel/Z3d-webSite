<?php
require_once '../../config/headers.php';
require_once '../../config/database.php';

try {
    // Recibe datos JSON
    $data = json_decode(file_get_contents('php://input'), true);
    $admin = $data['admin'] ?? '';
    $password = $data['password'] ?? '';

    if (empty($admin) || empty($password)) {
        echo json_encode(['success' => false, 'error' => 'Usuario y contraseña son requeridos']);
        exit;
    }

    // Obtener conexión
    $pdo = getConnection();

    // Consulta para verificar credenciales
    $stmt = $pdo->prepare("SELECT * FROM z3d_useradmin WHERE Admin = ? AND password = ?");
    $stmt->execute([$admin, $password]);
    $user = $stmt->fetch();

    if ($user) {
        echo json_encode([
            'success' => true, 
            'user' => [
                'id' => $user['id'],
                'admin' => $user['Admin']
            ],
            'message' => 'Login exitoso'
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Credenciales incorrectas']);
    }

} catch (Exception $e) {
    echo json_encode(handleDatabaseError($e));
}
?>
