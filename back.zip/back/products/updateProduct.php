<?php
require_once '../../config/headers.php';
require_once '../../config/database.php';

try {
    // Recibe datos JSON
    $data = json_decode(file_get_contents('php://input'), true);

    $id = $data['id'] ?? null;
    $nombre = $data['nombre'] ?? '';
    $precio = $data['precio'] ?? 0;
    $img = $data['img'] ?? '';
    $descripcion = $data['descripcion'] ?? '';

    if (!$id) {
        echo json_encode(['success' => false, 'error' => 'ID de producto requerido']);
        exit;
    }

    // Obtener conexión
    $pdo = getConnection();

    $stmt = $pdo->prepare("UPDATE productos SET nombre = ?, precio = ?, img = ?, descripcion = ? WHERE id = ?");
    $success = $stmt->execute([$nombre, $precio, $img, $descripcion, $id]);
    
    if ($success) {
        echo json_encode(['success' => true, 'message' => 'Producto actualizado correctamente']);
    } else {
        echo json_encode(['success' => false, 'error' => 'No se pudo actualizar el producto']);
    }

} catch (Exception $e) {
    echo json_encode(handleDatabaseError($e));
}
?>
