<?php
require_once '../../config/headers.php';
require_once '../../config/database.php';

try {
    // Obtener conexión
    $pdo = getConnection();

    // Consulta para obtener todos los productos
    $stmt = $pdo->query("SELECT * FROM productos ORDER BY id DESC");
    $products = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true, 
        'products' => $products
    ]);

} catch (Exception $e) {
    echo json_encode(handleDatabaseError($e));
}
?>
