<?php
require_once '../../config/headers.php';
require_once '../../config/database.php';

try {
    $data = json_decode(file_get_contents('php://input'), true);

    $nombre = $data['nombre'] ?? '';
    $precio = $data['precio'] ?? 0;
    $img = $data['img'] ?? '';
    $descripcion = $data['descripcion'] ?? '';

    // Obtener conexión
    $pdo = getConnection();

    $stmt = $pdo->prepare("INSERT INTO productos (nombre, precio, img, descripcion) VALUES (?, ?, ?, ?)");
    $success = $stmt->execute([$nombre, $precio, $img, $descripcion]);
    
    if ($success) {
        echo json_encode([
            'success' => true, 
            'id' => $pdo->lastInsertId(), 
            'message' => 'Producto agregado correctamente'
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'No se pudo agregar el producto']);
    }

} catch (Exception $e) {
    echo json_encode(handleDatabaseError($e));
}
?>
