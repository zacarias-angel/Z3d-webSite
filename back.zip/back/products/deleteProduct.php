<?php
require_once '../../config/headers.php';
require_once '../../config/database.php';

try {
    // Recibe datos JSON
    $data = json_decode(file_get_contents('php://input'), true);

    $id = $data['id'] ?? null;

    if (!$id) {
        echo json_encode(['success' => false, 'error' => 'ID de producto requerido']);
        exit;
    }

    // Obtener conexión
    $pdo = getConnection();

    $stmt = $pdo->prepare("DELETE FROM productos WHERE id = ?");
    $success = $stmt->execute([$id]);
    
    if ($success && $stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Producto eliminado correctamente']);
    } else {
        echo json_encode(['success' => false, 'error' => 'No se pudo eliminar el producto o no existe']);
    }

} catch (Exception $e) {
    echo json_encode(handleDatabaseError($e));
}
?>
